Built.Extension.define('hello', function(request, response) {
  return response.success('Hello World');
});
